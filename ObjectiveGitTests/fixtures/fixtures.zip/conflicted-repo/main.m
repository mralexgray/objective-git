//
//  main.m
//  Test
//
//  Created by Joe Ricioppo on 9/28/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
123456789
123456789
123456789
<<<<<<< HEAD
123456789blah
=======
123456789!blah!
>>>>>>> production
