#import <Foundation/Foundation.h>

@interface NSValue (Expecta)

- (const char *)_EXP_objCType;
- (void)set_EXP_objCType:(const char *)_EXP_objCType;

@end
