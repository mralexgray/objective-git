#import "Expecta.h"

EXPMatcherInterface(beKindOf, (Class expected));

#define beAKindOf beKindOf
