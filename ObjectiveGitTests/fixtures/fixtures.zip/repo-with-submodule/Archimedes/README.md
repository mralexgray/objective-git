# Archimedes

Archimedes contains useful geometry functions for your Cocoa or Cocoa Touch application.

This framework is very much a work in progress at the moment, and should be considered **alpha quality**. Breaking changes may happen often during this time.

## Getting Started

To start building the framework, clone this repository and then run `script/bootstrap`.
This will automatically pull down any dependencies.

## License

Archimedes is released under the MIT license. See [LICENSE.md](https://github.com/github/Archimedes/blob/master/LICENSE.md).
