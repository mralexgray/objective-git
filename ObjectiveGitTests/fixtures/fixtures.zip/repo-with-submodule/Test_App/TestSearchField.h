//
//  TestSearchField.h
//  Test
//
//  Created by Joe Ricioppo on 9/29/10.
//  Copyright 2010 GitHub. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TestSearchField : NSSearchField {

}

@end
